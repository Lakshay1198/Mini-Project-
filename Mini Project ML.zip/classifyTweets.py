
# importing libraries

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import re
import nltk
import os.path
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from sklearn.feature_extraction.text import CountVectorizer

# getting common words dictionary
with open('words2.txt') as word_file:
  words = set(word_file.read().split())

# getting training dataset
dataset = pd.read_csv('train.csv',encoding='iso-8859-1',names=['Status','Tweets'])

# training the model
def trainModel():
    global refTweets
    global classifier
    global cv
    if(not os.path.exists('refinedTweets.csv')):
        # cleaning data
        for i in range(0, len(dataset)):
            tweet = re.sub('[^a-zA-Z]', ' ', dataset['Tweets'][i])
            tweet = tweet.lower()
            tweet = tweet.split()
            ps = PorterStemmer()
            tweet = [ps.stem(word) for word in tweet if not word in set(stopwords.words('english'))]
            tweet= ' '.join(tweet)
            refTweets.append(tweet)
    else:
         refTweets = pd.read_csv('refinedTweets.csv')

    A = pd.DataFrame({'RefTweets':refTweets.iloc[0:50000,0].values})
    A = A['RefTweets'].astype(str).tolist()
    B = pd.DataFrame({'RefTweets':refTweets.iloc[998576:,0].values})
    B = B['RefTweets'].astype(str).tolist()
    A.extend(B)
    refTweets = A

    # preparing dataset
    cv = CountVectorizer(max_features = 3000)
    X = cv.fit_transform(refTweets).toarray()
    y1 = dataset.iloc[0:50000, 0].values
    y2 = dataset.iloc[998576:, 0].values
    testY= np.concatenate((y1,y2))
    y=testY
    # Fitting Logistic Regression to the Training set
    from sklearn.linear_model import LogisticRegression
    classifier = LogisticRegression(random_state = 0)
    classifier.fit(X, y)
    print("Model trained")



def getPredictedResult(screen_name):
      global tweets
      global corpus
      global predictedY
      tweets = pd.read_csv(screen_name+'_tweets.csv')
      corpus=[]
      print(len(tweets))
      # cleaning the data
      for i in range(0, len(tweets)):
            tweet = re.sub('[^a-zA-Z]', ' ', tweets['text'][i])
            tweet = tweet.lower()
            tweet = tweet.split()
            ps = PorterStemmer()
            tweet = [ps.stem(word) for word in tweet if not word in set(stopwords.words('english'))]
            tweet = [word for word in tweet if word in words]
            tweet = ' '.join(tweet)
            corpus.append(tweet)
      X = cv.transform(corpus).toarray()
      # predicting the result
      predictedY = classifier.predict(X)
      Status=[]
      for i in predictedY :
        if(i==0):
          Status.append('Negative')
        else:
          Status.append('Positive')
      tweets['Status'] = Status

      return tweets
# when first time script will be loaded model will be trained
trainModel()
