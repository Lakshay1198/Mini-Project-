
#impoertig libraries
import sys
import SearchTweets
import pandas as pd
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *

#main window
class MainWindow(QMainWindow):

    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setWindowTitle("")
        self.form_widget = FormWidget(self)
        #_widget =QWidget()
        #_layout = QVBoxLayout(_widget)
        #_layout.addWidget(self.form_widget)
        self.setCentralWidget(self.form_widget)

        mainMenu = self.menuBar()
        fileMenu = mainMenu.addMenu('File')
        editMenu = mainMenu.addMenu('Edit')
        viewMenu = mainMenu.addMenu('View')
        searchMenu = mainMenu.addMenu('Search')
        toolsMenu = mainMenu.addMenu('Tools')
        helpMenu = mainMenu.addMenu('Help')

        fontButton = QAction('Font', self)
        fontButton.triggered.connect(self.on_click)

        toolsMenu.addAction(fontButton)
        self.setFixedSize(853.33,480)




    @pyqtSlot()
    def on_click(self):
        print('PyQt5 button click')
        font, ok = QFontDialog.getFont()
        if ok:
            self.setFont(font)


class FormWidget(QWidget):

    def __init__(self, parent):
        super(FormWidget, self).__init__(parent)
        self.__layout()
        self.__controls()


    def __layout(self):

         label = QLabel(self)
         pixmap = QPixmap('Twitter_pic.jpg')
         pixmap = pixmap.scaled(853.3,480)
         label.setPixmap(pixmap)
         self.resize(pixmap.width(),pixmap.height())
         label =QLabel(self)
         label.setText("Enter Name to search Tweets")
         label.setStyleSheet('color:blue')
         label.setFont(QFont('MSShellDlg2',14))
         label.resize(250,50)
         label.move(50,50)
         self.setFont(QFont('MSShellDlg2',14))
         #text box to get screenName
         self.textbox = QLineEdit(self)
         self.textbox.move(50, 100)
         self.textbox.resize(250,25)
         self.textbox.setStyleSheet('color:blue')
         srchButton = QPushButton('SEARCH', self)
         srchButton.setToolTip('search tweets')
         srchButton.move(50,150)
         srchButton.clicked.connect(self.search)
         #self.createTable()
         '''self.layout = QVBoxLayout()
         self.layout.addWidget(self.tableWidget)
         self.setLayout(self.layout)'''

    def __controls(self):
         print("",end="")


    @pyqtSlot()
    def search(self):
        global screenName
        screenName = self.textbox.text()
        #tweets = SearchTweets.get_all_tweets(self.textbox.text())
        self.table=Table(self)
        self.table.show()
             #print(tweets)
             #self.createTable(len(tweets),2)


class Table(QWidget):

    def __init__(self, parent=None):
        super(Table, self).__init__()
        self.__layout()
        self.__controls()

        self.setFixedSize(853.33,480)
    def __layout(self):
        label =QLabel(self)
        label.setText("Enter Name to search Tweets")
        label.setStyleSheet('color:blue')
        label.setFont(QFont('MSShellDlg2',14))
        label.resize(250,50)
        label.move(50,50)
        self.createTable()
        self.layout = QVBoxLayout()
        self.layout.addWidget(self.tableWidget)
        self.setLayout(self.layout)


    def __controls(self):
        print("",end="")

    def createTable(self):
        #get all tweets along with prediction
        dataset =  SearchTweets.get_all_tweets(screenName)
        self.tableWidget = QTableWidget()
        self.tableWidget.setVerticalHeaderLabels(('Id', 'Created_At', 'Tweet','Status'))
        self.tableWidget.setRowCount(len(dataset))
        self.tableWidget.setColumnCount(4)
        self.tableWidget.setColumnWidth(0, 30)
        self.tableWidget.setColumnWidth(1, 160)
        print(len(dataset))

        for r in range(0,len(dataset)):

            self.tableWidget.setItem(r, 0, QTableWidgetItem(str(dataset.iat[r,0])))
            self.tableWidget.setItem(r, 1, QTableWidgetItem(dataset.iat[r,1]))
            self.tableWidget.setItem(r, 2, QTableWidgetItem(dataset.iat[r,2]))
            self.tableWidget.setItem(r, 3, QTableWidgetItem(dataset.iat[r,3]))
        self.tableWidget.move(0, 0)



def main():
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    app.exec_()

if __name__ == '__main__':
    sys.exit(main())
